package com.mentor.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mentor.Dao.RoomDao;
import com.mentor.beans.RoomBeans;


@Controller
public class Room {
	@Autowired
    RoomDao dao;
	@RequestMapping(value="/view/addroom",method=RequestMethod.POST)
	public void addProduct(HttpServletRequest req,HttpServletResponse res,@ModelAttribute("addproduct") RoomBeans addproduct) throws IOException,ServletException 
	{
		int sucess=dao.addproduct(addproduct);
		if(sucess>0)
		{
			System.out.print("Your data sucessfully inserted");
			res.sendRedirect("../sucesserror/addroomsuccess.jsp");
		}
		System.out.println("Hello room");
	}
	
	/********************Getting Room List************************************/
	@RequestMapping(value="/view/roomlist",method=RequestMethod.GET) 
	public ModelAndView showSupplier() throws IOException,ServletException
	{
	    System.out.println("Hello show supplier");
	    List<RoomBeans> list=dao.getRooms();
		return new ModelAndView("roomlist","list",list);
	
	}
	
	/*************************************************************************/
	/********************Getting Room List************************************/
	@RequestMapping(value="/view/roomlist1",method=RequestMethod.GET)
	public ModelAndView showSupplier1(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
	    System.out.println("Hello show supplier");
	    String rmid=req.getParameter("rmid");
	    List<RoomBeans> list=dao.getRoom2(rmid);
		return new ModelAndView("addnewstudent","list",list);
	
	}
	
	//////////////////////////////////////////////
	
	@RequestMapping(value="/view/delete1",method=RequestMethod.GET)
	public void delete(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
     String id=req.getParameter("rmid");
  
     int status= dao.deleteRooms(id);
     if(status>0)
     {
      res.sendRedirect("roomlist.hostel");
     }
     else
     {
    	 System.out.println("Not sucess");
     }
     
	}////delete function ends
	
	


}
