package com.mentor.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mentor.Dao.PaymentDao;
import com.mentor.beans.PaymentBean;


@Controller
public class Payment {
	@Autowired
    PaymentDao dao;
	@RequestMapping(value="/view/addpayment",method=RequestMethod.POST)
	public void addStudent(HttpServletRequest req,HttpServletResponse res,@ModelAttribute("payment") PaymentBean payment) throws IOException,ServletException 
	{
		int sucess=dao.addPayment(payment);
		if(sucess>0)
		{
			System.out.print("Your data sucessfully inserted");
			res.sendRedirect("../sucesserror/addroomsuccess.jsp");
		}
		System.out.println("Hello room");
	}
	

}
