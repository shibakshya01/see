package com.mentor.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mentor.Dao.StudentDao;
import com.mentor.beans.StudentBeans;
import com.mentor.beans.StudentReportBean;
@Controller
public class Student {
	@Autowired
    StudentDao dao;
	@RequestMapping(value="/view/addstudent",method=RequestMethod.POST)
	public void addStudent(HttpServletRequest req,HttpServletResponse res,@ModelAttribute("student") StudentBeans student) throws IOException,ServletException 
	{
		int sucess=dao.addStudent(student);
		if(sucess>0)
		{
			System.out.print("Your data sucessfully inserted");
			res.sendRedirect("../sucesserror/addstsucess.jsp");
		}
		System.out.println("Hello room");
	}
	
	/********************Getting Student list***********************************************/
	@RequestMapping(value="/view/studentlist",method=RequestMethod.GET) 
	public ModelAndView studentList() throws IOException,ServletException
	{
	    System.out.println("Hello show supplier");
	    List<StudentBeans> list=dao.getStudents();
		return new ModelAndView("studentlist","list",list);
	
	}
	/**************************************************************************/
	/********************Getting Room List************************************/
	@RequestMapping(value="/view/studentlist1",method=RequestMethod.GET)
	public ModelAndView showSupplier1(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
	    System.out.println("Hello show supplier");
	    String stuid=req.getParameter("stuid");
	    List<StudentBeans> list=dao.getStudent2(stuid);
		return new ModelAndView("addpayment","list",list);
	
	}
	
	/*******************************************************************************************/
	
	@RequestMapping(value="/view/studentreport",method=RequestMethod.GET) 
	public ModelAndView studentReport() throws IOException,ServletException
	{
	    System.out.println("Hello show supplier");
	    List<StudentReportBean> list=dao.getStudentReport();
		return new ModelAndView("studentreport","list",list);
	
	}
	
	/////////////////////////////////////////////
	@RequestMapping(value="/view/deletestudent",method=RequestMethod.GET)
	public void delete(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
     String id=req.getParameter("stdid");
  
     int status= dao.deleteStudents(id);
     if(status>0)
     {
      res.sendRedirect("studentlist.hostel");
     }
     else
     {
    	 System.out.println("Not sucess");
     }
     
	}////delete function ends
	
	

}
