package com.mentor.beans;

public class PaymentBean {
private String paymentid;
private String paymentamount;
private String paymentdate;
private String stdid;
public String getPaymentid() {
	return paymentid;
}
public void setPaymentid(String paymentid) {
	this.paymentid = paymentid;
}
public String getPaymentamount() {
	return paymentamount;
}
public void setPaymentamount(String paymentamount) {
	this.paymentamount = paymentamount;
}
public String getPaymentdate() {
	return paymentdate;
}
public void setPaymentdate(String paymentdate) {
	this.paymentdate = paymentdate;
}
public String getStdid() {
	return stdid;
}
public void setStdid(String stdid) {
	this.stdid = stdid;
}

}
