package com.mentor.beans;

public class RoomBeans {
private String rmid,rmcode,numofbed,rmfeepbed,totfee,rmtype;

public String getRmid() {
	return rmid;
}

public void setRmid(String rmid) {
	this.rmid = rmid;
}

public String getRmcode() {
	return rmcode;
}

public void setRmcode(String rmcode) {
	this.rmcode = rmcode;
}

public String getNumofbed() {
	return numofbed;
}

public void setNumofbed(String numofbed) {
	this.numofbed = numofbed;
}

public String getRmfeepbed() {
	return rmfeepbed;
}

public void setRmfeepbed(String rmfeepbed) {
	this.rmfeepbed = rmfeepbed;
}

public String getTotfee() {
	return totfee;
}

public void setTotfee(String totfee) {
	this.totfee = totfee;
}

public String getRmtype() {
	return rmtype;
}

public void setRmtype(String rmtype) {
	this.rmtype = rmtype;
}
	

}
