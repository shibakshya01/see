package com.mentor.beans;

public class StudentBeans {
	private String stdid;
	private String stdfname;
	private String stdlname;
	private String stdemail;
	private String stdgender;
	private String stdnumber;///this is student number
	private String stdlocation;
	private String stdclgname;
	private String stdgname;
	private String stdgnumber;////this is guradian number
	private String rmid;
	public String getStdid() {
		return stdid;
	}
	public void setStdid(String stdid) {
		this.stdid = stdid;
	}
	public String getStdfname() {
		return stdfname;
	}
	public void setStdfname(String stdfname) {
		this.stdfname = stdfname;
	}
	public String getStdlname() {
		return stdlname;
	}
	public void setStdlname(String stdlname) {
		this.stdlname = stdlname;
	}
	public String getStdemail() {
		return stdemail;
	}
	public void setStdemail(String stdemail) {
		this.stdemail = stdemail;
	}
	public String getStdgender() {
		return stdgender;
	}
	public void setStdgender(String stdgender) {
		this.stdgender = stdgender;
	}
	public String getStdnumber() {
		return stdnumber;
	}
	public void setStdnumber(String stdnumber) {
		this.stdnumber = stdnumber;
	}
	public String getStdlocation() {
		return stdlocation;
	}
	public void setStdlocation(String stdlocation) {
		this.stdlocation = stdlocation;
	}
	public String getStdclgname() {
		return stdclgname;
	}
	public void setStdclgname(String stdclgname) {
		this.stdclgname = stdclgname;
	}
	public String getStdgname() {
		return stdgname;
	}
	public void setStdgname(String stdgname) {
		this.stdgname = stdgname;
	}
	public String getStdgnumber() {
		return stdgnumber;
	}
	public void setStdgnumber(String stdgnumber) {
		this.stdgnumber = stdgnumber;
	}
	public String getRmid() {
		return rmid;
	}
	public void setRmid(String rmid) {
		this.rmid = rmid;
	}
	
}
