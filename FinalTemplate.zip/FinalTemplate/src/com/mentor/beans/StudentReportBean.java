package com.mentor.beans;

public class StudentReportBean {
	private String stdfname,stdlname,stdphone,paidamount,paiddate;

	public String getStdfname() {
		return stdfname;
	}

	public void setStdfname(String stdfname) {
		this.stdfname = stdfname;
	}

	public String getStdlname() {
		return stdlname;
	}

	public void setStdlname(String stdlname) {
		this.stdlname = stdlname;
	}

	public String getStdphone() {
		return stdphone;
	}

	public void setStdphone(String stdphone) {
		this.stdphone = stdphone;
	}

	public String getPaidamount() {
		return paidamount;
	}

	public void setPaidamount(String paidamount) {
		this.paidamount = paidamount;
	}

	public String getPaiddate() {
		return paiddate;
	}

	public void setPaiddate(String paiddate) {
		this.paiddate = paiddate;
	}

}
