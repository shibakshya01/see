package com.mentor.Dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.mentor.beans.RoomBeans;




public class RoomDao {
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	} 
	public int addproduct(RoomBeans pd)
	{
		String sql="insert into room values(null,'"+pd.getRmcode()+"','"+pd.getNumofbed()+"','"+pd.getRmfeepbed()+"','"+pd.getTotfee()+"','"+pd.getRmtype()+"')";
		return template.update(sql);
	}
	
	/***************Getting room from database*********************/
	
	public List<RoomBeans> getRooms() throws IOException,ServletException{  
	    return template.query("select * from room",new RowMapper<RoomBeans>(){  
	        public RoomBeans mapRow(ResultSet rs, int row) throws SQLException {  
	            RoomBeans room=new RoomBeans();
	            room.setRmid(rs.getString(1));
	            room.setRmcode(rs.getString(2));
	            room.setNumofbed(rs.getString(3));
	            room.setRmfeepbed(rs.getString(4));
	            room.setTotfee(rs.getString(5));
	            room.setRmtype(rs.getString(6)); 
	            return room;  
	        }  
	    }); 
	}///getEmployee ends
	
	
	/***************************************************************/
	public List<RoomBeans> getRoom2(String rmid)
	{
		 return template.query("select * from room where rmid='"+rmid+"'",new RowMapper<RoomBeans>(){  
		        public RoomBeans mapRow(ResultSet rs, int row) throws SQLException {  
		            RoomBeans room=new RoomBeans();
		            room.setRmid(rs.getString(1));
		            room.setRmcode(rs.getString(2));
		            room.setNumofbed(rs.getString(3));
		            room.setRmfeepbed(rs.getString(4));
		            room.setTotfee(rs.getString(5));
		            room.setRmtype(rs.getString(6)); 
		            return room;  
		        }  
		    }); 
		
	}
	/****************************Deleting room********************************************/
	public int deleteRooms(String spl)
	{
		String sql="delete from room where rmid='"+spl+"'";
		return template.update(sql);
	}

}
