package com.mentor.Dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.mentor.beans.StudentBeans;
import com.mentor.beans.StudentReportBean;

public class StudentDao {
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	} 
	public int addStudent(StudentBeans st)
	{
		String sql="insert into student values(null,'"+st.getStdfname()+"','"+ st.getStdlname() + "','"+ st.getStdemail()+"','"+st.getStdgender()+"','"+st.getStdnumber()+"','"+st.getStdlocation()+"','"+st.getStdclgname()+"','"+st.getStdgname()+"','"+st.getStdgnumber()+"','"+st.getRmid()+"')";
		return template.update(sql);
	}
	
	
	/******************************************************************************************************/
	public List<StudentBeans> getStudents() throws IOException,ServletException{  
	    return template.query("select * from student",new RowMapper<StudentBeans>(){  
	        public StudentBeans mapRow(ResultSet rs, int row) throws SQLException {  
	            StudentBeans st =new StudentBeans();
	            st.setStdid(rs.getString(1));
	            st.setStdfname(rs.getString(2));
	            st.setStdlname(rs.getString(3));
	            st.setStdemail(rs.getString(4));
	            st.setStdgender(rs.getString(5));
	            st.setStdnumber(rs.getString(6));
	            st.setStdlocation(rs.getString(7));
	            st.setStdclgname(rs.getString(8));
	            st.setStdgname(rs.getString(9));
	            st.setStdgnumber(rs.getString(10));
	            st.setRmid(rs.getString(11));
	            return st;  
	        }  
	    }); 
	}///getEmployee ends
	
	public List<StudentBeans> getStudent2(String stdid)
	{
		 return template.query("select * from student where stdid='"+stdid+"'",new RowMapper<StudentBeans>(){  
		        public StudentBeans mapRow(ResultSet rs, int row) throws SQLException {  
		            StudentBeans st =new StudentBeans();
		            st.setStdid(rs.getString(1));
		            st.setStdfname(rs.getString(2));
		            st.setStdlname(rs.getString(3));
		            st.setStdemail(rs.getString(4));
		            st.setStdgender(rs.getString(5));
		            st.setStdnumber(rs.getString(6));
		            st.setStdlocation(rs.getString(7));
		            st.setStdclgname(rs.getString(8));
		            st.setStdgname(rs.getString(9));
		            st.setStdgnumber(rs.getString(10));
		            st.setRmid(rs.getString(11));
		            return st; 
		        }  
		    }); 
		
	}
	
	/*******************************Report************************************************************/
	public List<StudentReportBean> getStudentReport() throws IOException,ServletException{  
	    return template.query("select * from streport",new RowMapper<StudentReportBean>(){  
	        public StudentReportBean mapRow(ResultSet rs, int row) throws SQLException {  
	            StudentReportBean st =new StudentReportBean();
	            st.setStdfname(rs.getString(1));
	            st.setStdlname(rs.getString(2));
	            st.setStdphone(rs.getString(3));
	            st.setPaidamount(rs.getString(4));
	            st.setPaiddate(rs.getString(5));
	            return st;  
	        }  
	    }); 
	}///getEmployee ends
	public int deleteStudents(String stdid)
	{
		String sql="delete from student where stdid='"+stdid+"'";
		return template.update(sql);
	}

	

}
