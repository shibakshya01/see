package com.mentor.Dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mentor.beans.PaymentBean;


public class PaymentDao {
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	} 
	public int addPayment(PaymentBean pd)
	{
		String sql="insert into payment values(null,'"+pd.getPaymentamount()+"','"+pd.getPaymentdate()+"','"+pd.getStdid()+"')";
		return template.update(sql);
	}
	

}
